#! /usr/bin/env python

from src import main
main.main()

